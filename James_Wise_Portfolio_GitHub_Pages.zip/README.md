# James Wise — Personal Portfolio

A polished, responsive portfolio built with plain HTML, CSS, JavaScript, original SVG illustrations, and a **separately prepared public-contact résumé PDF**. No build tools, paid hosting, framework, or backend are required.

## Before making it public — important

- **Review `assets/resume.pdf` carefully before uploading.** It is a *new, public-contact adaptation* of `Resume924.pdf`, not a redacted original or exact duplicate. The original résumé has not been changed and is intentionally **not included** in this site.
- The original résumé includes a personal phone number. The new PDF intentionally omits it. The website also omits the original résumé's phone number and does not publish a street address.
- This site publicly displays the contact email you explicitly provided: **wisejames2008@gmail.com**.
- A public GitHub Pages site is available to anyone on the internet, and every file you upload to a public repository—including PDFs and image assets—is accessible to the public. Do not upload private documents or contact information you do not want shared.
- Review the project descriptions, scholarship wording, graduation year, GPA, and source-derived content before publishing.

## Files

```text
jamesmwis.github.io/
├── index.html                    # Content, sections, links and semantic structure
├── styles.css                    # Layout, fonts, UGA-inspired colors, responsiveness
├── script.js                     # Mobile menu and year
├── .nojekyll                     # Prevents unneeded Jekyll processing
├── README.md                     # This guide
└── assets/
    ├── resume.pdf                # New public-contact résumé PDF: REVIEW FIRST
    └── images/
        ├── hero-engineering.svg  # Geometric engineering illustration in hero
        ├── project-vision.svg    # Engineering-project concept illustration
        ├── research-sex-ratio.svg # Scientific research card illustration
        ├── research-herbicide.svg # Scientific research card illustration
        ├── favicon.svg          # Browser tab icon
        └── social-card.svg      # Social sharing image
```

All current illustrations are **original vector graphics**. None represents an actual photo of your work, experiments, or face. No headshot or campus image was provided, so the site does not show a fabricated one.

### Optional personal photos

Place your own photos here, with these suggested names:

| Optional file | Suggested website placement |
| --- | --- |
| `assets/images/profile.jpg` | Hero or About section; update `index.html` to display it |
| `assets/images/college.jpg` | Education section; update `index.html` |
| `assets/images/project-1.jpg` | Engineering project visual; replace `assets/images/project-vision.svg` reference in `index.html` |
| `assets/images/project-2.jpg` | Research or a future engineering card; update `index.html` |
| `assets/images/hero-background.jpg` | Hero background; edit `styles.css` |

JPG, PNG, or WebP work. Use the real filename and extension in the HTML/CSS; don't rename unnecessarily. Add descriptive alt text and avoid photos you do not have permission to share.

## Preview locally

Simplest: double-click `index.html` to open it in a browser. Most features work directly this way. PDF previews may vary by browser and local file permissions.

More reliable: from this folder, run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/` in your browser. Stop the server with Ctrl+C. No installation is required beyond Python if you use the server method.

## Publish to GitHub Pages using the website (beginner path)

1. Sign in to [GitHub](https://github.com/) as **`jamesmwis`**.
2. Create a new **public** repository named exactly **`jamesmwis.github.io`** (use that case/spelling). The repository's exact name is important for a user site.
3. On the repository page, select **Add file → Upload files**. Open the downloaded website folder and upload its **contents**, preserving `assets/` and its subfolders. `index.html` must be at the repository root, **not** inside an extra `jamesmwis.github.io/` folder. Some upload interfaces may not preserve hidden `.nojekyll`; for this plain site it is optional.
4. Select **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, then branch **`main`** and folder **`/(root)`**, and **Save**.
6. Open the **Actions** tab to view the Pages build/deployment run. When it succeeds, open **https://jamesmwis.github.io/**. The site's **Settings → Pages** screen also displays the site address when it has published.

If the repository already exists, upload files to its root or follow the Git approach below. Do not overwrite other work you want to keep.

### Publish using Git from a terminal (alternative)

In a terminal opened inside `jamesmwis.github.io/`:

```bash
git init
git add .
git commit -m "Launch engineering portfolio"
git branch -M main
git remote add origin https://github.com/jamesmwis/jamesmwis.github.io.git
git push -u origin main
```

Create the empty GitHub repository first. Sign in with an approved GitHub authentication method if prompted. If there is already a remote or a README in the remote repository, merge/coordinate those changes before pushing; don't force push blindly.

## Your expected URL

**https://jamesmwis.github.io/**

Because the repository name matches **`USERNAME.github.io`**, GitHub serves it at the root. For an ordinary project repository such as `my-portfolio`, the URL is `https://jamesmwis.github.io/my-portfolio/`; that repository name is a *path*, not a separate domain. This site uses relative paths for local and project-subpath compatibility.

## Troubleshooting

- **404 / site not found:** Confirm the exact repository name and owner, that `index.html` is at the published root, and `Settings → Pages` uses `main` and `/(root)`. Check **Actions** for deployment errors and give deployment a few minutes to finish.
- **Missing images:** Confirm the `assets/images/` folder and letter-for-letter filenames, including uppercase/lowercase differences. Use browser DevTools → Network to inspect 404 errors. Do not add `/` at the front of local image paths for project sites.
- **Résumé does not appear:** Confirm `assets/resume.pdf` exists and is committed. Test the direct URL `https://jamesmwis.github.io/assets/resume.pdf`. Some browsers block inline PDF viewing; use the Open or Download link.
- **Layout missing:** Confirm `styles.css` and `script.js` are alongside `index.html`, not inside an extra nested folder.
- **Fonts look different:** Online Google Fonts may be blocked or unavailable; the website includes system font fallbacks.
- **Older site appears:** Refresh without cache (Ctrl+Shift+R) and check whether the new Pages deployment succeeded.

Official guide: [Configuring a publishing source for your GitHub Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Update the site later

- **Text, jobs, dates, achievements, links:** edit `index.html`, save, commit/upload.
- **Colors, typography, spacing:** edit `styles.css`. Main colors are in the `:root` variables at the top; `--red` is UGA-inspired red.
- **Mobile menu:** edit `script.js` if needed.
- **Résumé:** replace `assets/resume.pdf` with a reviewed public-safe edition using the **same filename**. That preserves the site's preview and links. The original source PDF should remain private if it has personal contact information.
- **Images:** replace an existing graphic with a similarly sized image and update `index.html` paths and alt text. Images use responsive sizing.
- **Add a project:** copy the `feature-project` structure in the Engineering section or a `research-card` in Research, then edit the contents and imagery. Avoid labeling project targets as results.
- Commit changes to `main`; GitHub Pages updates after the new deployment completes.

## Optional custom domain

You can use a domain you separately own. Configure it in **Settings → Pages → Custom domain**, then configure the corresponding DNS records with your domain provider, and enable HTTPS once available. Verify ownership and use the current [official GitHub Pages custom-domain instructions](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site). A repository name by itself does **not** provide a standalone domain.

## Notes on content sourcing

The uploaded résumé is the primary source. The Framer editor link led to a sign-in page, so this design is **independently created**, not a confirmed recreation of the Framer template. LinkedIn could not be read from its public URL; the site links to the profile but does not claim any information from it. The web-based project illustrations are concept art, not field photographs. Project performance figures such as FPS and detection precision are marked as *goals* rather than measured results. The GitHub profile link is inferred directly from the provided username: `jamesmwis`.
